from django.contrib import admin

from HH_app.models import Resume, Vacancy

# Register your models here.
admin.site.register(Resume)
admin.site.register(Vacancy)